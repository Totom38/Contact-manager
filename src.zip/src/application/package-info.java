/**
 * Package containing JavaFX elements: Application, Controller, etc
 */
package application;
