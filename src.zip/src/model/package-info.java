/**
 * package containing Contacts data structures
 */
package model;
