/**
 * Simple package containing a Logger factory in order to simply create several
 * Loggers using either console or files
 * @author davidroussel
 */
package logger;